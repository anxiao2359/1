package mysql.lianqiao.registerDao;

import java.nio.channels.ClosedSelectorException;
import java.sql.*;
import com.mysql.jdbc.Driver;

public class registerDao {
    public int register(String name, String password, String sex, String tel, String adress, String email){
        String URL="jdbc:mysql://localhost:3306/test?characterEncoding=utf8";
        String USERNAME="root";
        String PWD="307411";

        int count = -1;
        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            //导入驱动，加载具体驱动类
            Class.forName("com.mysql.jdbc.Driver");
            //与数据库建立联系
            connection = DriverManager.getConnection(URL, USERNAME, PWD);
            //发送sql，执行
            String sql1 = "select count(*) from login where name=?";
            pstmt = connection.prepareStatement(sql1);
            pstmt.setString(1, name);
            rs = pstmt.executeQuery();
            System.out.println(rs);

            int result = -1;             //查询用户名是否有人用
            while (rs.next()) {
                result = rs.getInt(1);
            }
            if (result > 0) {
                count = 0;
                return count;
            }





            else {
                try{


                    String sql = "insert into login(name,password,sex,tel,adress,email) values(?,?,?,?,?,?)";
                    pstmt = connection.prepareStatement(sql);
                    pstmt.setString(1, name);
                    pstmt.setString(2, password);
                    pstmt.setString(3, sex);
                    pstmt.setString(4, tel);
                    pstmt.setString(5, adress);
                    pstmt.setString(6, email);


                    count = pstmt.executeUpdate();
                    System.out.println(count);
                    return count;


                } catch (SQLException e) {
                    e.printStackTrace();
                    return -1;
                } catch (Exception e) {
                    e.printStackTrace();
                    return -1;
                }finally {
                    try{
                        if(rs!=null) rs.close();
                        if(pstmt!=null) rs.close();
                        if(connection!=null) connection.close();
                    }catch (SQLException e){
                        e.printStackTrace();
                        return -1;
                    }
                }
                }


    }catch (ClassNotFoundException e){
            e.printStackTrace();
            return -1;
        }catch (SQLException e){
            e.printStackTrace();
            return -1;
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }finally {
            try{
                if(rs!=null) rs.close();
                if(pstmt!=null) rs.close();
                if(connection!=null) connection.close();
            }catch (SQLException e){
                e.printStackTrace();
                return -1;
            }catch (Exception e){
                e.printStackTrace();
                e.printStackTrace();
            }
        }
        }
}
