package mysql.lianqiao.quryDao;

import mysql.lianqiao.Person;

import java.sql.*;

public class quryDao {
    public Person query(String name) {
        Person person = new Person();

        String URL = "jdbc:mysql://localhost:3306/test?characterEncoding=utf8";
        String USERNAME = "root";
        String PASSWORD = "307411";

        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL,USERNAME,PASSWORD);
            String sql = "select *from login where name=?";
           pstmt =  connection.prepareStatement(sql);
           pstmt.setString(1,name);
           rs = pstmt.executeQuery();

           if(rs.next()){
               person.setName(rs.getString("name"));
               person.setPassword( rs.getString("password"));
               person.setSex( rs.getString("sex"));
               person.setTel(rs.getString("tel"));
               person.setAdress(rs.getString("adress"));
               person.setEmail(rs.getString("email"));

           }

           return person;

        }catch (ClassNotFoundException e){
            e.printStackTrace();
            return null;
        }catch (SQLException e){
            e.printStackTrace();
            return null;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }finally {
            try {
                if(rs!=null) rs.close();
                if(pstmt!=null) pstmt.close();
                if(connection!=null) connection.close();
            }catch (SQLException e){
                e.printStackTrace();
            }catch (Exception e){
                e.printStackTrace();

            }
        }
    }
}
