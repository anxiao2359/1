package mysql.lianqiao.LoginDao;

import java.sql.*;
import com.mysql.jdbc.Driver;

public class LoginDao {
    public int login(String name,String password) {//1:登录成功 0：登陆失败（用户名或密码错误） -1：系统异常
        String URL="jdbc:mysql://localhost:3306/test?characterEncoding=utf8";
        String USERNAME="root";
        String PWD="307411";
        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try{
            //导入驱动，加载具体驱动类
            Class.forName("com.mysql.jdbc.Driver");
            //与数据库建立联系
            connection = DriverManager.getConnection(URL,USERNAME,PWD);
            //发送sql，执行


            String sql = "select * from login where name=? and password=? ";
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1,name);
            pstmt.setString(2,password);
            rs = pstmt.executeQuery();

            //处理结果
            String count = null;
            int result = -1;
            while(rs.next()){
                count = rs.getString(1);
                result = 1;

            }
            return result;


        }catch (ClassNotFoundException e){
            e.printStackTrace();
            return -1;
        }catch (SQLException e){
            e.printStackTrace();
            return -1;
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }
        finally {
            try{
                if(rs!=null) rs.close();
                if(pstmt!=null) pstmt.close();
                if(connection!=null) connection.close();
            }catch (SQLException e){
                e.printStackTrace();
            }

        }
    }

}
