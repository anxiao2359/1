package mysql.lianqiao.updateDao;

import java.sql.*;
import com.mysql.jdbc.Driver;

public class updateDao {

    public int update(String name,String password){
        String URL="jdbc:mysql://localhost:3306/test?characterEncoding=utf8";
        String USERNAME="root";
        String PWD="307411";
        Connection connection = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = -1;

        try{
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL,USERNAME,PWD);
            String sql = "update login set password=? where name=?";
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1,password);
            pstmt.setString(2,name);
            count = pstmt.executeUpdate();

            return count;


        }catch (ClassNotFoundException e){
            e.printStackTrace();
            return -1;
        }catch (SQLException e){
            e.printStackTrace();
            return -1;
        }catch (Exception e){
            e.printStackTrace();
            return -1;
        }finally {
            try{
                if(rs!=null) rs.close();
                if(pstmt!=null) pstmt.close();
                if(connection!=null) connection.close();
            }catch (SQLException e){
                e.printStackTrace();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
